<?php

namespace EmpresaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EmpresaBundle extends Bundle
{
}
