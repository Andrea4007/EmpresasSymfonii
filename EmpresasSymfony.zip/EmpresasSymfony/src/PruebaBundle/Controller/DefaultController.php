<?php

namespace PruebaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="prueba_home")
     */
    public function indexAction()
    {
        return $this->render('PruebaBundle:Default:index.html.twig');
    }
      /**
     * @Route("/inicio", name="prueba_inicio")
     */
    public function inicioAction()
    {
        return $this->render('PruebaBundle:Default:inicio.html.twig');
    }
}
