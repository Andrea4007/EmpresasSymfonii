<?php

namespace PruebaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PruebaBundle extends Bundle
{
}
