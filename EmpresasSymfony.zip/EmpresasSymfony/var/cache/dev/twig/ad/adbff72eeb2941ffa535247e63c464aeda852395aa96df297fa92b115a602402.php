<?php

/* EmpresaBundle:Default:index.html.twig */
class __TwigTemplate_c28a154442ab09559d6d1dec2613c2b9147ac293c1ee2f16408258fdcc61dbfb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b502273f2d239068169438b9285f0453fdd1a89bb527356be1e859180876122 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b502273f2d239068169438b9285f0453fdd1a89bb527356be1e859180876122->enter($__internal_6b502273f2d239068169438b9285f0453fdd1a89bb527356be1e859180876122_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EmpresaBundle:Default:index.html.twig"));

        $__internal_df0cf3b2e444e4c2cd69557b4fa315baacc2a1ef1bc01d9e8f3207a6b62a73e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df0cf3b2e444e4c2cd69557b4fa315baacc2a1ef1bc01d9e8f3207a6b62a73e1->enter($__internal_df0cf3b2e444e4c2cd69557b4fa315baacc2a1ef1bc01d9e8f3207a6b62a73e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EmpresaBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_6b502273f2d239068169438b9285f0453fdd1a89bb527356be1e859180876122->leave($__internal_6b502273f2d239068169438b9285f0453fdd1a89bb527356be1e859180876122_prof);

        
        $__internal_df0cf3b2e444e4c2cd69557b4fa315baacc2a1ef1bc01d9e8f3207a6b62a73e1->leave($__internal_df0cf3b2e444e4c2cd69557b4fa315baacc2a1ef1bc01d9e8f3207a6b62a73e1_prof);

    }

    public function getTemplateName()
    {
        return "EmpresaBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "EmpresaBundle:Default:index.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\src\\EmpresaBundle/Resources/views/Default/index.html.twig");
    }
}
