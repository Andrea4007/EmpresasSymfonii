<?php

/* frontal/index.html.twig */
class __TwigTemplate_e366863157e4f1f294153b152aa77559a5ee85bc4d780a6efa47058706be8973 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "frontal/index.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9ebef47dbe5a4377adda7bf034caebbbd21805f2b7459e8505a940291c6c988 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9ebef47dbe5a4377adda7bf034caebbbd21805f2b7459e8505a940291c6c988->enter($__internal_c9ebef47dbe5a4377adda7bf034caebbbd21805f2b7459e8505a940291c6c988_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontal/index.html.twig"));

        $__internal_f042dbd3dd7dbb23a06101035befc8b7a00bb55edce975e716b3dac2722ee717 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f042dbd3dd7dbb23a06101035befc8b7a00bb55edce975e716b3dac2722ee717->enter($__internal_f042dbd3dd7dbb23a06101035befc8b7a00bb55edce975e716b3dac2722ee717_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "frontal/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c9ebef47dbe5a4377adda7bf034caebbbd21805f2b7459e8505a940291c6c988->leave($__internal_c9ebef47dbe5a4377adda7bf034caebbbd21805f2b7459e8505a940291c6c988_prof);

        
        $__internal_f042dbd3dd7dbb23a06101035befc8b7a00bb55edce975e716b3dac2722ee717->leave($__internal_f042dbd3dd7dbb23a06101035befc8b7a00bb55edce975e716b3dac2722ee717_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_263d7144d4c8e1d47f80e3d6eaaa136d4abe01604d02da51e991e1a12bfe62c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_263d7144d4c8e1d47f80e3d6eaaa136d4abe01604d02da51e991e1a12bfe62c8->enter($__internal_263d7144d4c8e1d47f80e3d6eaaa136d4abe01604d02da51e991e1a12bfe62c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_c34426b928c3f46bf4feef84c7873c47845c1fd6e24ed3864ff4ff1a5c43b275 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c34426b928c3f46bf4feef84c7873c47845c1fd6e24ed3864ff4ff1a5c43b275->enter($__internal_c34426b928c3f46bf4feef84c7873c47845c1fd6e24ed3864ff4ff1a5c43b275_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 5
        echo "Pagina principal
";
        
        $__internal_c34426b928c3f46bf4feef84c7873c47845c1fd6e24ed3864ff4ff1a5c43b275->leave($__internal_c34426b928c3f46bf4feef84c7873c47845c1fd6e24ed3864ff4ff1a5c43b275_prof);

        
        $__internal_263d7144d4c8e1d47f80e3d6eaaa136d4abe01604d02da51e991e1a12bfe62c8->leave($__internal_263d7144d4c8e1d47f80e3d6eaaa136d4abe01604d02da51e991e1a12bfe62c8_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_d55ce92f33dbfc9b3d401ac8af8e7dde4b586d4f329f91bf8f750d9797bc6fc7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d55ce92f33dbfc9b3d401ac8af8e7dde4b586d4f329f91bf8f750d9797bc6fc7->enter($__internal_d55ce92f33dbfc9b3d401ac8af8e7dde4b586d4f329f91bf8f750d9797bc6fc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0d2e969619aa00d37b3bfe252bb691a23e0d2fc7dd5e76f5793bbe7c88343995 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d2e969619aa00d37b3bfe252bb691a23e0d2fc7dd5e76f5793bbe7c88343995->enter($__internal_0d2e969619aa00d37b3bfe252bb691a23e0d2fc7dd5e76f5793bbe7c88343995_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0d2e969619aa00d37b3bfe252bb691a23e0d2fc7dd5e76f5793bbe7c88343995->leave($__internal_0d2e969619aa00d37b3bfe252bb691a23e0d2fc7dd5e76f5793bbe7c88343995_prof);

        
        $__internal_d55ce92f33dbfc9b3d401ac8af8e7dde4b586d4f329f91bf8f750d9797bc6fc7->leave($__internal_d55ce92f33dbfc9b3d401ac8af8e7dde4b586d4f329f91bf8f750d9797bc6fc7_prof);

    }

    public function getTemplateName()
    {
        return "frontal/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 8,  50 => 5,  41 => 4,  11 => 2,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# Plantilla de nuestra aplicacion#}
{% extends \"base.html.twig\" %}
{# titulo de la pagina esto es un comentario #}
{% block title %}
Pagina principal
{% endblock %}
{# Contenido de la pagina este es un comentario #}
{% block body %}
{% endblock %}", "frontal/index.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\app\\Resources\\views\\frontal\\index.html.twig");
    }
}
