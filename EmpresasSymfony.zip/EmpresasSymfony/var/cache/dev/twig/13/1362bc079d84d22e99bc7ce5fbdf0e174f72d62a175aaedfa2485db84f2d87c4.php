<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_ce8d70d332d109182a423d11a79f5687d6696079e761c1b61667a1a8f39214d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12cd52be00e57a3464aa35a0b443075f2cb38ced2293b4abe383d6758b295486 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12cd52be00e57a3464aa35a0b443075f2cb38ced2293b4abe383d6758b295486->enter($__internal_12cd52be00e57a3464aa35a0b443075f2cb38ced2293b4abe383d6758b295486_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_68264823bd4b0192936a7a22dc640697ec0a724ed3f72697f408f9814b34240a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_68264823bd4b0192936a7a22dc640697ec0a724ed3f72697f408f9814b34240a->enter($__internal_68264823bd4b0192936a7a22dc640697ec0a724ed3f72697f408f9814b34240a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_12cd52be00e57a3464aa35a0b443075f2cb38ced2293b4abe383d6758b295486->leave($__internal_12cd52be00e57a3464aa35a0b443075f2cb38ced2293b4abe383d6758b295486_prof);

        
        $__internal_68264823bd4b0192936a7a22dc640697ec0a724ed3f72697f408f9814b34240a->leave($__internal_68264823bd4b0192936a7a22dc640697ec0a724ed3f72697f408f9814b34240a_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8d4997795e0753f450998596fa06f18236e9eb1bc65abbb136b10db208b75f70 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d4997795e0753f450998596fa06f18236e9eb1bc65abbb136b10db208b75f70->enter($__internal_8d4997795e0753f450998596fa06f18236e9eb1bc65abbb136b10db208b75f70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_7b61d4b996b3250a79bbda92f9b4c62723b2711f44e30dce2d03062d759342b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b61d4b996b3250a79bbda92f9b4c62723b2711f44e30dce2d03062d759342b3->enter($__internal_7b61d4b996b3250a79bbda92f9b4c62723b2711f44e30dce2d03062d759342b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_7b61d4b996b3250a79bbda92f9b4c62723b2711f44e30dce2d03062d759342b3->leave($__internal_7b61d4b996b3250a79bbda92f9b4c62723b2711f44e30dce2d03062d759342b3_prof);

        
        $__internal_8d4997795e0753f450998596fa06f18236e9eb1bc65abbb136b10db208b75f70->leave($__internal_8d4997795e0753f450998596fa06f18236e9eb1bc65abbb136b10db208b75f70_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_98134703489be8f2ddebc671b01e8f9f1676f93d228b30b8bd01346984edf347 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98134703489be8f2ddebc671b01e8f9f1676f93d228b30b8bd01346984edf347->enter($__internal_98134703489be8f2ddebc671b01e8f9f1676f93d228b30b8bd01346984edf347_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_b71681dc1345347283496002630b949f5b97b1056bbd644390950b44e12893eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b71681dc1345347283496002630b949f5b97b1056bbd644390950b44e12893eb->enter($__internal_b71681dc1345347283496002630b949f5b97b1056bbd644390950b44e12893eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_b71681dc1345347283496002630b949f5b97b1056bbd644390950b44e12893eb->leave($__internal_b71681dc1345347283496002630b949f5b97b1056bbd644390950b44e12893eb_prof);

        
        $__internal_98134703489be8f2ddebc671b01e8f9f1676f93d228b30b8bd01346984edf347->leave($__internal_98134703489be8f2ddebc671b01e8f9f1676f93d228b30b8bd01346984edf347_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_8a06c633d1a06200475755cf5bada902b3b08b6cd87e32d52c066aa6ad00723b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a06c633d1a06200475755cf5bada902b3b08b6cd87e32d52c066aa6ad00723b->enter($__internal_8a06c633d1a06200475755cf5bada902b3b08b6cd87e32d52c066aa6ad00723b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_403398029ba3d65cc2f05c79065cf4f956f579ef03d5707da7d81198c9fa264b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_403398029ba3d65cc2f05c79065cf4f956f579ef03d5707da7d81198c9fa264b->enter($__internal_403398029ba3d65cc2f05c79065cf4f956f579ef03d5707da7d81198c9fa264b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_403398029ba3d65cc2f05c79065cf4f956f579ef03d5707da7d81198c9fa264b->leave($__internal_403398029ba3d65cc2f05c79065cf4f956f579ef03d5707da7d81198c9fa264b_prof);

        
        $__internal_8a06c633d1a06200475755cf5bada902b3b08b6cd87e32d52c066aa6ad00723b->leave($__internal_8a06c633d1a06200475755cf5bada902b3b08b6cd87e32d52c066aa6ad00723b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
