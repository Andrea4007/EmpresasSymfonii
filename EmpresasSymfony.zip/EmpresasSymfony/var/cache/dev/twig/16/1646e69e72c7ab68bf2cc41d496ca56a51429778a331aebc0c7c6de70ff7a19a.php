<?php

/* base.html.twig */
class __TwigTemplate_b1994ee407fe470ce57bb138618009cc0215c05eacac7b34c9ef04b3fc70e71c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d392a3d977aa7a77db0ba27032abac47acd00d925bf25b44d52eadd87d438f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5d392a3d977aa7a77db0ba27032abac47acd00d925bf25b44d52eadd87d438f5->enter($__internal_5d392a3d977aa7a77db0ba27032abac47acd00d925bf25b44d52eadd87d438f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_5fadb99b14a8b9366c283ca5d16280352505e1c24567b8b069b8bced9cd7848f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fadb99b14a8b9366c283ca5d16280352505e1c24567b8b069b8bced9cd7848f->enter($__internal_5fadb99b14a8b9366c283ca5d16280352505e1c24567b8b069b8bced9cd7848f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <!--Estilos css with materialize-->
         <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendor/css/materialize.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\"/>
         <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendor/css/style.css"), "html", null, true);
        echo "\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\"/>
         <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendor/font-awesome-4.3.0/css/font-awesome.min.css"), "html", null, true);
        echo "\">
         <link rel=\"shortcut icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("vendor/favicon (7).ico"), "html", null, true);
        echo "\" type=\"image/x-icon\">
         <link rel=\"icon\" href=\"";
        // line 11
        echo "vendor/favicon (7).ico\" type=\"image/x-icon";
        echo "\">
        <!--Aqui termina de agregar estilos css-->
        ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 18
        echo "        \t<style>
\t\t.fa{
\t\t\tcolor:#ef6c00;
\t\t}
\t</style>

   <nav class=\"orange darken-2\">
    <div class=\"nav-wrapper\">
      <a href=\"#!\" class=\"brand-logo\">Logo</a>
      <a href=\"#\" data-activates=\"mobile-demo\" class=\"button-collapse\"><i class=\"mdi-navigation-menu\"></i></a>
      <ul class=\"right hide-on-med-and-down\">
        <li><a href=\"#\">Home</a></li>
        <li><a href=\"#\">Login</a></li>
      </ul>
      <ul class=\"side-nav\" id=\"mobile-demo\">
       <li><a href=\"#\">Home</a></li>
        <li><a href=\"#\">Login</a></li>
      </ul>
    </div>
  </nav>
        




        <!--  Scripts-->
        <script src=\"https://code.jquery.com/jquery-2.1.1.min.js\"></script>
        <script src=\"js/materialize.js\"></script>
        <script src=\"js/init.js\"></script>

        <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-60673008-2', 'auto');
        ga('send', 'pageview');
        </script>
        ";
        // line 56
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "    </body>
</html>
";
        
        $__internal_5d392a3d977aa7a77db0ba27032abac47acd00d925bf25b44d52eadd87d438f5->leave($__internal_5d392a3d977aa7a77db0ba27032abac47acd00d925bf25b44d52eadd87d438f5_prof);

        
        $__internal_5fadb99b14a8b9366c283ca5d16280352505e1c24567b8b069b8bced9cd7848f->leave($__internal_5fadb99b14a8b9366c283ca5d16280352505e1c24567b8b069b8bced9cd7848f_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f27f2a1c3542bf12ee702e07f1cdc60bfbdf0d1211ebeb1472cee522bdec8cb9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f27f2a1c3542bf12ee702e07f1cdc60bfbdf0d1211ebeb1472cee522bdec8cb9->enter($__internal_f27f2a1c3542bf12ee702e07f1cdc60bfbdf0d1211ebeb1472cee522bdec8cb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ccd16e3764ba925acdac9d99b17a8b88063823fc5eaa7b0f905572571426eeb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccd16e3764ba925acdac9d99b17a8b88063823fc5eaa7b0f905572571426eeb4->enter($__internal_ccd16e3764ba925acdac9d99b17a8b88063823fc5eaa7b0f905572571426eeb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_ccd16e3764ba925acdac9d99b17a8b88063823fc5eaa7b0f905572571426eeb4->leave($__internal_ccd16e3764ba925acdac9d99b17a8b88063823fc5eaa7b0f905572571426eeb4_prof);

        
        $__internal_f27f2a1c3542bf12ee702e07f1cdc60bfbdf0d1211ebeb1472cee522bdec8cb9->leave($__internal_f27f2a1c3542bf12ee702e07f1cdc60bfbdf0d1211ebeb1472cee522bdec8cb9_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d22429e7323d42823c9ffa2a5919599d8e1394d3b0462ba3f04582452be99f46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d22429e7323d42823c9ffa2a5919599d8e1394d3b0462ba3f04582452be99f46->enter($__internal_d22429e7323d42823c9ffa2a5919599d8e1394d3b0462ba3f04582452be99f46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_5f50febf7fefbfe56a492c5abc142ab0623b4504013b9e39d8cd698e039ad302 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f50febf7fefbfe56a492c5abc142ab0623b4504013b9e39d8cd698e039ad302->enter($__internal_5f50febf7fefbfe56a492c5abc142ab0623b4504013b9e39d8cd698e039ad302_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_5f50febf7fefbfe56a492c5abc142ab0623b4504013b9e39d8cd698e039ad302->leave($__internal_5f50febf7fefbfe56a492c5abc142ab0623b4504013b9e39d8cd698e039ad302_prof);

        
        $__internal_d22429e7323d42823c9ffa2a5919599d8e1394d3b0462ba3f04582452be99f46->leave($__internal_d22429e7323d42823c9ffa2a5919599d8e1394d3b0462ba3f04582452be99f46_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_66de0217f8c241eba2543bb81a63536b308529f7ac84064e2355e97f95c6381d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66de0217f8c241eba2543bb81a63536b308529f7ac84064e2355e97f95c6381d->enter($__internal_66de0217f8c241eba2543bb81a63536b308529f7ac84064e2355e97f95c6381d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7d0d01828d39ee600f9657b399ff408085f8f3805e1210857f40eb0e5f9087c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d0d01828d39ee600f9657b399ff408085f8f3805e1210857f40eb0e5f9087c6->enter($__internal_7d0d01828d39ee600f9657b399ff408085f8f3805e1210857f40eb0e5f9087c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_7d0d01828d39ee600f9657b399ff408085f8f3805e1210857f40eb0e5f9087c6->leave($__internal_7d0d01828d39ee600f9657b399ff408085f8f3805e1210857f40eb0e5f9087c6_prof);

        
        $__internal_66de0217f8c241eba2543bb81a63536b308529f7ac84064e2355e97f95c6381d->leave($__internal_66de0217f8c241eba2543bb81a63536b308529f7ac84064e2355e97f95c6381d_prof);

    }

    // line 56
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3754594c20a04666dc58e3ffd09c855da64903511f7bf8b96e9d75c3b66dafc8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3754594c20a04666dc58e3ffd09c855da64903511f7bf8b96e9d75c3b66dafc8->enter($__internal_3754594c20a04666dc58e3ffd09c855da64903511f7bf8b96e9d75c3b66dafc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_2df1e490cb581d8618f42bd4b50a69e522b4a235d48efaefe14ab8430d86d2cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2df1e490cb581d8618f42bd4b50a69e522b4a235d48efaefe14ab8430d86d2cd->enter($__internal_2df1e490cb581d8618f42bd4b50a69e522b4a235d48efaefe14ab8430d86d2cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_2df1e490cb581d8618f42bd4b50a69e522b4a235d48efaefe14ab8430d86d2cd->leave($__internal_2df1e490cb581d8618f42bd4b50a69e522b4a235d48efaefe14ab8430d86d2cd_prof);

        
        $__internal_3754594c20a04666dc58e3ffd09c855da64903511f7bf8b96e9d75c3b66dafc8->leave($__internal_3754594c20a04666dc58e3ffd09c855da64903511f7bf8b96e9d75c3b66dafc8_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 56,  161 => 17,  144 => 13,  126 => 5,  114 => 57,  112 => 56,  72 => 18,  70 => 17,  63 => 14,  61 => 13,  56 => 11,  52 => 10,  48 => 9,  44 => 8,  40 => 7,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        <!--Estilos css with materialize-->
         <link href=\"{{ asset('vendor/css/materialize.css') }}\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\"/>
         <link href=\"{{ asset('vendor/css/style.css') }}\" type=\"text/css\" rel=\"stylesheet\" media=\"screen,projection\"/>
         <link rel=\"stylesheet\" href=\"{{ asset('vendor/font-awesome-4.3.0/css/font-awesome.min.css') }}\">
         <link rel=\"shortcut icon\" href=\"{{ asset('vendor/favicon (7).ico') }}\" type=\"image/x-icon\">
         <link rel=\"icon\" href=\"{{ ('vendor/favicon (7).ico\" type=\"image/x-icon') }}\">
        <!--Aqui termina de agregar estilos css-->
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        \t<style>
\t\t.fa{
\t\t\tcolor:#ef6c00;
\t\t}
\t</style>

   <nav class=\"orange darken-2\">
    <div class=\"nav-wrapper\">
      <a href=\"#!\" class=\"brand-logo\">Logo</a>
      <a href=\"#\" data-activates=\"mobile-demo\" class=\"button-collapse\"><i class=\"mdi-navigation-menu\"></i></a>
      <ul class=\"right hide-on-med-and-down\">
        <li><a href=\"#\">Home</a></li>
        <li><a href=\"#\">Login</a></li>
      </ul>
      <ul class=\"side-nav\" id=\"mobile-demo\">
       <li><a href=\"#\">Home</a></li>
        <li><a href=\"#\">Login</a></li>
      </ul>
    </div>
  </nav>
        




        <!--  Scripts-->
        <script src=\"https://code.jquery.com/jquery-2.1.1.min.js\"></script>
        <script src=\"js/materialize.js\"></script>
        <script src=\"js/init.js\"></script>

        <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
        ga('create', 'UA-60673008-2', 'auto');
        ga('send', 'pageview');
        </script>
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\app\\Resources\\views\\base.html.twig");
    }
}
