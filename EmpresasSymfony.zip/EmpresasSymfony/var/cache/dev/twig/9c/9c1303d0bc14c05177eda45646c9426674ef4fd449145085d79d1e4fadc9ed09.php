<?php

/* PruebaBundle:Default:index.html.twig */
class __TwigTemplate_b07174e23f72d9e2256031aeb73e95d3aef5ca928cda29f5947e69827b015065 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_70a491211725592f66c96172b579b0e36ef16e91b014457ae45431e90c9441fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_70a491211725592f66c96172b579b0e36ef16e91b014457ae45431e90c9441fe->enter($__internal_70a491211725592f66c96172b579b0e36ef16e91b014457ae45431e90c9441fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PruebaBundle:Default:index.html.twig"));

        $__internal_f4432fa3505e943d87640d9e37e7d92cfa26a486b8ce634441c7b0229d81c4af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4432fa3505e943d87640d9e37e7d92cfa26a486b8ce634441c7b0229d81c4af->enter($__internal_f4432fa3505e943d87640d9e37e7d92cfa26a486b8ce634441c7b0229d81c4af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PruebaBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_70a491211725592f66c96172b579b0e36ef16e91b014457ae45431e90c9441fe->leave($__internal_70a491211725592f66c96172b579b0e36ef16e91b014457ae45431e90c9441fe_prof);

        
        $__internal_f4432fa3505e943d87640d9e37e7d92cfa26a486b8ce634441c7b0229d81c4af->leave($__internal_f4432fa3505e943d87640d9e37e7d92cfa26a486b8ce634441c7b0229d81c4af_prof);

    }

    public function getTemplateName()
    {
        return "PruebaBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Hello World!
", "PruebaBundle:Default:index.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\src\\PruebaBundle/Resources/views/Default/index.html.twig");
    }
}
