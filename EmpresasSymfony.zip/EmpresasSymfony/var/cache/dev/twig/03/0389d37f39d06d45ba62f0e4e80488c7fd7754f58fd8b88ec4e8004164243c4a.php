<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_bf5f3ea779923a4964912c545fa8c6d5e39f7418e2221835e6037cbbc3aaa78c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f194331709d734c492573dd6110145391c120d8dc9eb41e8a67e1789f3a5396e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f194331709d734c492573dd6110145391c120d8dc9eb41e8a67e1789f3a5396e->enter($__internal_f194331709d734c492573dd6110145391c120d8dc9eb41e8a67e1789f3a5396e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_8ab57fdbcb3c97742e5e5d37c6749600aa18428de2dece2bf773dacacf4ee5a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ab57fdbcb3c97742e5e5d37c6749600aa18428de2dece2bf773dacacf4ee5a0->enter($__internal_8ab57fdbcb3c97742e5e5d37c6749600aa18428de2dece2bf773dacacf4ee5a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f194331709d734c492573dd6110145391c120d8dc9eb41e8a67e1789f3a5396e->leave($__internal_f194331709d734c492573dd6110145391c120d8dc9eb41e8a67e1789f3a5396e_prof);

        
        $__internal_8ab57fdbcb3c97742e5e5d37c6749600aa18428de2dece2bf773dacacf4ee5a0->leave($__internal_8ab57fdbcb3c97742e5e5d37c6749600aa18428de2dece2bf773dacacf4ee5a0_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_2ba0fbf73e27c9d96d1f5f25898145a75c7504b6612d0f4920c70a6e7e47570c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2ba0fbf73e27c9d96d1f5f25898145a75c7504b6612d0f4920c70a6e7e47570c->enter($__internal_2ba0fbf73e27c9d96d1f5f25898145a75c7504b6612d0f4920c70a6e7e47570c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_61733689448efbbb0fce7b02ec1f520ba450f4bae3c6b953f50abc8a102493b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61733689448efbbb0fce7b02ec1f520ba450f4bae3c6b953f50abc8a102493b7->enter($__internal_61733689448efbbb0fce7b02ec1f520ba450f4bae3c6b953f50abc8a102493b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_61733689448efbbb0fce7b02ec1f520ba450f4bae3c6b953f50abc8a102493b7->leave($__internal_61733689448efbbb0fce7b02ec1f520ba450f4bae3c6b953f50abc8a102493b7_prof);

        
        $__internal_2ba0fbf73e27c9d96d1f5f25898145a75c7504b6612d0f4920c70a6e7e47570c->leave($__internal_2ba0fbf73e27c9d96d1f5f25898145a75c7504b6612d0f4920c70a6e7e47570c_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_2caebc8d5fa43d0b2ca5ca3840f123f1d5e5f1aa215b4d41b6c69d6fb6590467 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2caebc8d5fa43d0b2ca5ca3840f123f1d5e5f1aa215b4d41b6c69d6fb6590467->enter($__internal_2caebc8d5fa43d0b2ca5ca3840f123f1d5e5f1aa215b4d41b6c69d6fb6590467_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_bf6927bf98cef3fa5e6c3359f13ec27edb99fe396d77ae0352aae2e952a1feb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bf6927bf98cef3fa5e6c3359f13ec27edb99fe396d77ae0352aae2e952a1feb4->enter($__internal_bf6927bf98cef3fa5e6c3359f13ec27edb99fe396d77ae0352aae2e952a1feb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_bf6927bf98cef3fa5e6c3359f13ec27edb99fe396d77ae0352aae2e952a1feb4->leave($__internal_bf6927bf98cef3fa5e6c3359f13ec27edb99fe396d77ae0352aae2e952a1feb4_prof);

        
        $__internal_2caebc8d5fa43d0b2ca5ca3840f123f1d5e5f1aa215b4d41b6c69d6fb6590467->leave($__internal_2caebc8d5fa43d0b2ca5ca3840f123f1d5e5f1aa215b4d41b6c69d6fb6590467_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8f6a2133507b55f899672fa4cbf8314e89e4d071bf0108ecede286a228126739 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f6a2133507b55f899672fa4cbf8314e89e4d071bf0108ecede286a228126739->enter($__internal_8f6a2133507b55f899672fa4cbf8314e89e4d071bf0108ecede286a228126739_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_a95bff2c473e5acd92ff9641032e47547abf0c7ce8a6e1af9d54542598ed21b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a95bff2c473e5acd92ff9641032e47547abf0c7ce8a6e1af9d54542598ed21b9->enter($__internal_a95bff2c473e5acd92ff9641032e47547abf0c7ce8a6e1af9d54542598ed21b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_a95bff2c473e5acd92ff9641032e47547abf0c7ce8a6e1af9d54542598ed21b9->leave($__internal_a95bff2c473e5acd92ff9641032e47547abf0c7ce8a6e1af9d54542598ed21b9_prof);

        
        $__internal_8f6a2133507b55f899672fa4cbf8314e89e4d071bf0108ecede286a228126739->leave($__internal_8f6a2133507b55f899672fa4cbf8314e89e4d071bf0108ecede286a228126739_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
