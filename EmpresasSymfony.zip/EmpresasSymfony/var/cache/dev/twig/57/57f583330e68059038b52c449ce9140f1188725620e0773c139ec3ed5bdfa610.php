<?php

/* @Twig/Exception/traces.txt.twig */
class __TwigTemplate_a98c0580991ca436fc1c782af155af5972765153b5e1693c32448c2ce16b96e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2115bc999fe311067bd6e9a4a1b28c4dc8e2e94248083c3113301bf49cb74fe9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2115bc999fe311067bd6e9a4a1b28c4dc8e2e94248083c3113301bf49cb74fe9->enter($__internal_2115bc999fe311067bd6e9a4a1b28c4dc8e2e94248083c3113301bf49cb74fe9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        $__internal_e02a9626361b63b03d3927c55ef58311f399c7fd01144bf82a2fe45f420f2ce6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e02a9626361b63b03d3927c55ef58311f399c7fd01144bf82a2fe45f420f2ce6->enter($__internal_e02a9626361b63b03d3927c55ef58311f399c7fd01144bf82a2fe45f420f2ce6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        // line 1
        if (twig_length_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "trace", array()))) {
            // line 2
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "trace", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
                // line 3
                $this->loadTemplate("@Twig/Exception/trace.txt.twig", "@Twig/Exception/traces.txt.twig", 3)->display(array("trace" => $context["trace"]));
                // line 4
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        
        $__internal_2115bc999fe311067bd6e9a4a1b28c4dc8e2e94248083c3113301bf49cb74fe9->leave($__internal_2115bc999fe311067bd6e9a4a1b28c4dc8e2e94248083c3113301bf49cb74fe9_prof);

        
        $__internal_e02a9626361b63b03d3927c55ef58311f399c7fd01144bf82a2fe45f420f2ce6->leave($__internal_e02a9626361b63b03d3927c55ef58311f399c7fd01144bf82a2fe45f420f2ce6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  31 => 3,  27 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if exception.trace|length %}
{% for trace in exception.trace %}
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

{% endfor %}
{% endif %}
", "@Twig/Exception/traces.txt.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\traces.txt.twig");
    }
}
