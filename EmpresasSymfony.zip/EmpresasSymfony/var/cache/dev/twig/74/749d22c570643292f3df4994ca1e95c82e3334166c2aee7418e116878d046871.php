<?php

/* PruebaBundle:Default:inicio.html.twig */
class __TwigTemplate_a08066e8a2e386bbd75c77ea7814d0a90964a0d8e86e65f309a02fe2c68a2841 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_829e496fa29a9c30fdb1c860fead5fa45aa207563ed0de59e99f48c809604cce = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_829e496fa29a9c30fdb1c860fead5fa45aa207563ed0de59e99f48c809604cce->enter($__internal_829e496fa29a9c30fdb1c860fead5fa45aa207563ed0de59e99f48c809604cce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PruebaBundle:Default:inicio.html.twig"));

        $__internal_16d9bbeb8a7eb55a9ad985d77804541c4a2a88ad37fcd1a357356b022a4ab7b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16d9bbeb8a7eb55a9ad985d77804541c4a2a88ad37fcd1a357356b022a4ab7b5->enter($__internal_16d9bbeb8a7eb55a9ad985d77804541c4a2a88ad37fcd1a357356b022a4ab7b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PruebaBundle:Default:inicio.html.twig"));

        // line 1
        echo "<html>
    <meta charset=\"UTF-8\">
    <title>";
        // line 3
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 4
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "</head>
<body>
<h1 class=\"grey\">It works !</h1>
<a class=\"waves-effect waves-light btn\">button</a>
<a class=\"waves-effect waves-light btn\"><i class=\"material-icons left\">cloud</i>button</a>
<a class=\"waves-effect waves-light btn\"><i class=\"material-icons right\">cloud</i>button</a>

";
        // line 14
        $this->displayBlock('body', $context, $blocks);
        // line 15
        echo "    ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 19
        echo "</body>
 </html>";
        
        $__internal_829e496fa29a9c30fdb1c860fead5fa45aa207563ed0de59e99f48c809604cce->leave($__internal_829e496fa29a9c30fdb1c860fead5fa45aa207563ed0de59e99f48c809604cce_prof);

        
        $__internal_16d9bbeb8a7eb55a9ad985d77804541c4a2a88ad37fcd1a357356b022a4ab7b5->leave($__internal_16d9bbeb8a7eb55a9ad985d77804541c4a2a88ad37fcd1a357356b022a4ab7b5_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_3b851f6ac57b8a607b239d0668f971c6c7f85fccfac8b6d7bd43c8f41e050877 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b851f6ac57b8a607b239d0668f971c6c7f85fccfac8b6d7bd43c8f41e050877->enter($__internal_3b851f6ac57b8a607b239d0668f971c6c7f85fccfac8b6d7bd43c8f41e050877_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0b61fd6a96982a8e77b4d1ee22dd60f19b9250d3e9f12eb5455a87c9238b4975 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b61fd6a96982a8e77b4d1ee22dd60f19b9250d3e9f12eb5455a87c9238b4975->enter($__internal_0b61fd6a96982a8e77b4d1ee22dd60f19b9250d3e9f12eb5455a87c9238b4975_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_0b61fd6a96982a8e77b4d1ee22dd60f19b9250d3e9f12eb5455a87c9238b4975->leave($__internal_0b61fd6a96982a8e77b4d1ee22dd60f19b9250d3e9f12eb5455a87c9238b4975_prof);

        
        $__internal_3b851f6ac57b8a607b239d0668f971c6c7f85fccfac8b6d7bd43c8f41e050877->leave($__internal_3b851f6ac57b8a607b239d0668f971c6c7f85fccfac8b6d7bd43c8f41e050877_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_46b540bd38d240a98e4f2f00297150fe070c506d61ca89350820c1e54c11b221 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46b540bd38d240a98e4f2f00297150fe070c506d61ca89350820c1e54c11b221->enter($__internal_46b540bd38d240a98e4f2f00297150fe070c506d61ca89350820c1e54c11b221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_e108dad8dcd51717bca0912ece0b9f596f0126435478d706f32b3ff33268bec0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e108dad8dcd51717bca0912ece0b9f596f0126435478d706f32b3ff33268bec0->enter($__internal_e108dad8dcd51717bca0912ece0b9f596f0126435478d706f32b3ff33268bec0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    <link rel=\"stylesheet\" href=";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/app.css"), "html", null, true);
        echo "/>
    ";
        
        $__internal_e108dad8dcd51717bca0912ece0b9f596f0126435478d706f32b3ff33268bec0->leave($__internal_e108dad8dcd51717bca0912ece0b9f596f0126435478d706f32b3ff33268bec0_prof);

        
        $__internal_46b540bd38d240a98e4f2f00297150fe070c506d61ca89350820c1e54c11b221->leave($__internal_46b540bd38d240a98e4f2f00297150fe070c506d61ca89350820c1e54c11b221_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_87e918a66c667290b437301ac327c2e881deebc4bc564ab6112c68d4ee3552dd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87e918a66c667290b437301ac327c2e881deebc4bc564ab6112c68d4ee3552dd->enter($__internal_87e918a66c667290b437301ac327c2e881deebc4bc564ab6112c68d4ee3552dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_0adc5c93fe7cf3ebe991cf41f588f75e41edea3c465521952157d1f6834e3053 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0adc5c93fe7cf3ebe991cf41f588f75e41edea3c465521952157d1f6834e3053->enter($__internal_0adc5c93fe7cf3ebe991cf41f588f75e41edea3c465521952157d1f6834e3053_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0adc5c93fe7cf3ebe991cf41f588f75e41edea3c465521952157d1f6834e3053->leave($__internal_0adc5c93fe7cf3ebe991cf41f588f75e41edea3c465521952157d1f6834e3053_prof);

        
        $__internal_87e918a66c667290b437301ac327c2e881deebc4bc564ab6112c68d4ee3552dd->leave($__internal_87e918a66c667290b437301ac327c2e881deebc4bc564ab6112c68d4ee3552dd_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_06ceb0338a60b242775c1e73701937cb2d94ae5f8cfcc21e9642dbf7419f64bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06ceb0338a60b242775c1e73701937cb2d94ae5f8cfcc21e9642dbf7419f64bd->enter($__internal_06ceb0338a60b242775c1e73701937cb2d94ae5f8cfcc21e9642dbf7419f64bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_4c4526e6f764c6ef93992fd9df0efe83c6765afe2b4d32852d763b46d17e6b0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c4526e6f764c6ef93992fd9df0efe83c6765afe2b4d32852d763b46d17e6b0a->enter($__internal_4c4526e6f764c6ef93992fd9df0efe83c6765afe2b4d32852d763b46d17e6b0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 16
        echo "        <script src=";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/app.js"), "html", null, true);
        echo "></script>
        <script src=";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("build/manifest.js"), "html", null, true);
        echo "></script>
    ";
        
        $__internal_4c4526e6f764c6ef93992fd9df0efe83c6765afe2b4d32852d763b46d17e6b0a->leave($__internal_4c4526e6f764c6ef93992fd9df0efe83c6765afe2b4d32852d763b46d17e6b0a_prof);

        
        $__internal_06ceb0338a60b242775c1e73701937cb2d94ae5f8cfcc21e9642dbf7419f64bd->leave($__internal_06ceb0338a60b242775c1e73701937cb2d94ae5f8cfcc21e9642dbf7419f64bd_prof);

    }

    public function getTemplateName()
    {
        return "PruebaBundle:Default:inicio.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  135 => 17,  130 => 16,  121 => 15,  104 => 14,  91 => 5,  82 => 4,  64 => 3,  53 => 19,  50 => 15,  48 => 14,  39 => 7,  37 => 4,  33 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html>
    <meta charset=\"UTF-8\">
    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}
    <link rel=\"stylesheet\" href={{ asset(\"build/app.css\") }}/>
    {% endblock %}
</head>
<body>
<h1 class=\"grey\">It works !</h1>
<a class=\"waves-effect waves-light btn\">button</a>
<a class=\"waves-effect waves-light btn\"><i class=\"material-icons left\">cloud</i>button</a>
<a class=\"waves-effect waves-light btn\"><i class=\"material-icons right\">cloud</i>button</a>

{% block body %}{% endblock %}
    {% block javascripts %}
        <script src={{ asset(\"build/app.js\") }}></script>
        <script src={{ asset(\"build/manifest.js\") }}></script>
    {% endblock %}
</body>
 </html>", "PruebaBundle:Default:inicio.html.twig", "C:\\xampp\\htdocs\\EmpresasSymfony\\src\\PruebaBundle/Resources/views/Default/inicio.html.twig");
    }
}
